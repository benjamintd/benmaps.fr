# Asset and data licenses

- Style code and Clair POI geometry: original work, Clair License 1.0; see LICENSE.
- Four bundled Noto OpenType fonts in `assets/fonts`: SIL Open Font License 1.1; see `assets/fonts/OFL.txt`. Internal copyright and name records are retained. Distribution: https://github.com/notofonts/notofonts.github.io
- Noto Sans JP / SC / TC CJK WOFF2 subsets: SIL OFL, pinned Google Fonts URLs in `src/cjk-fonts.js`; fetched on demand, not included in the archive. https://github.com/notofonts/noto-cjk
- Baseline Noto Regular / Medium / Italic glyph PBFs: SIL OFL, fetched from Protomaps basemaps-assets. https://github.com/protomaps/basemaps-assets
- Baseline road shield / arrow / town-point sprites: MIT, fetched from Protomaps basemaps-assets. https://github.com/protomaps/basemaps-assets/tree/main/sprites
- Default Protomaps v4 vector source: OpenStreetMap contributors (ODbL) and Natural Earth (public domain); the style supplies attribution which must remain visible. Hosted API terms: https://protomaps.com/api
- Optional terrain: Mapzen Terrain Tiles / AWS Open Data. The source attribution links all underlying provider credits: https://github.com/tilezen/joerd/blob/master/docs/attribution.md
- Regional summit labels: 633 mountain points and available translated names from Natural Earth v5.1.2 `ne_10m_geography_regions_elevation_points`, public domain. Normalized data is embedded in `src/peak-data.js`. https://www.naturalearthdata.com/downloads/10m-physical-vectors/10m-physical-labels/ and https://www.naturalearthdata.com/about/terms-of-use/

MapLibre is the consuming renderer and is not bundled in this package. All remote sources can be replaced or mirrored; preserve the relevant attributions and licenses when self-hosting.

## Optional Latin typography

Commissioner (default), Google Sans, Source Sans 3, Inter, Inter Tight and Pliant
are bundled under SIL OFL 1.1, not the Clair commercial license. Each family has
its own copyright/license file under `assets/fonts/latin/`. See that directory's
README.md and SOURCES.json for upstream links, file hashes and modifications.
Commissioner is also used by the website. Source Sans 3 files remain unmodified
because its license reserves the name Source. No font is sold separately.
