# Style generator

## Public interface

`createStyle(options)` is a synchronous, pure factory. It returns an independent,
editable MapLibre style object. It performs no network or filesystem operations.
Callers supply a vector source or Protomaps key and choose language, density,
icons, layer groups and optional terrain/trees/building volumes. Camera state
belongs to the viewer. See README.md for options and source requirements.

Use a new factory call to change language. The exported regional peak source
contains only translations reachable by that style's language rules. Source
geometry and non-translation metadata are preserved.

## Modules

| Module                                           | Responsibility                                                                         |
| ------------------------------------------------ | -------------------------------------------------------------------------------------- |
| `index.js`                                       | Assemble layers and sources; assign groups; return an independent style                |
| `tokens.js`, `palette.js`                        | Semantic colors and small expression/layer constructors                                |
| `land.js`                                        | Land cover, land use, water and administrative boundaries                              |
| `roads.js`, `road-filters.js`, `street-scale.js` | Road classification, structure tiers, paving/crossings and estimated widths            |
| `buildings.js`, `trees.js`, `relief.js`          | Optional physical detail; heights, canopies and hillshading                            |
| `visibility.js`                                  | Shared interpretation of explicit surface/underground attributes                       |
| `labels.js`, `places.js`, `pois.js`              | Label and icon hierarchy, city prominence, category rules                              |
| `language.js`                                    | Name fallback, script selection and bilingual formatting                               |
| `fonts.js`                                       | Logical font stacks, script coverage and pinned font-file selection                    |
| `peaks.js`                                       | Regional/detail peak label handoff, elevations and language-specific source projection |

Road classes stay in one module: their casing/fill order and structure tiers
are tightly coupled. Avoid splitting the generator into one file per layer.
Font-file selection is separate from name selection so typography can evolve
without rewriting multilingual fallback rules.

## Layer order is part of behavior

Land and land use form the base. Hillshade goes below water. Building footprints
sit below transport linework; volumes sit above it. Within each transport tier
(tunnel, surface, bridge), all casings precede all fills so junctions remain open.
Crossings and stair marks remain in their structure tier. Surface trees sit above
ground roads and below bridges. Boundaries and building volumes precede labels.
Labels have their own ordered collision priorities. Never merge layers merely
because they share paint: ordering, filtering, zoom limits and collision behavior
must also remain equivalent.

## Global rules and source limitations

Rules use feature kind/detail, rank, population, capital status, geometry and
structural attributes. No city-name, coordinate or feature-ID exceptions.

- Underground structures hide when tags establish that status. Negative road
  layers can describe open cuttings, so roads use their own structure rules.
- Generalized tiles may omit burial tags. Canals remain visible at low zooms;
  the style does not guess which sections should be buried.
- Fountain labels are secondary water detail: regular small text from zoom 16,
  respecting the source min_zoom. Basin geometry remains independently visible.
- Widths and missing building heights are estimates. Preserve measured geometry
  where supplied; do not invent curbs or oriented crossings from points.

## Compact output

Keep the source readable; remove redundancy while generating JSON:

- Language expressions bind repeated candidates with `let`, preserving empty-name
  rejection, script fallback, deduplication and per-line formatting.
- Regional peaks retain the selected translation and English fallback, along
  with unqualified local names. Do not ship unused translations in every style.
- CJK singleton ranges use `U+ABCD` instead of `U+ABCD-ABCD`. Coverage and font-file
  order are unchanged. Logical font stacks still each need their fallback map.
- Numeric width arithmetic is resolved in JavaScript; neutral operations are
  omitted. Zoom interpolation stays at the expression's permitted top level.

Do not build a general expression optimizer or replace empty-string-aware name
selection with coalesce. Test equivalence at the factory interface before changing
compact expressions. API responses are minified JSON and CDN-compressed.

## Generated data and authoring inputs

- `palette.js` is generated from repository `design/palette.json` using
  `npm run palette`. It checks sRGB gamut and emits compatible hex colors.
- `peak-data.js` is a checked-in Natural Earth v5.1.2 elevation-point snapshot:
  https://www.naturalearthdata.com/downloads/10m-physical-vectors/10m-physical-labels/.
  Preserve coordinates, identifiers, names, elevations and ranking when updating.
  Source data is public domain; its default name is not always a local endonym.
- `cjk-fonts.js` is a checked-in snapshot of Noto Sans JP/SC/TC Google Fonts subsets.
  Each URL pins its font revision. Ranges came from the corresponding font CSS;
  preserve exact coverage and ordering if regenerating them. Fonts retain OFL
  terms. These tables are data, not hand-edited rendering rules.

## Verification and releases

From repository root, `npm test` validates the API and snapshots, compares old/new
label output (including formatted sections and elevations), checks every regional
peak's rendered text, compares font range coverage, and samples road widths across
zoom/link combinations. Additional tests cover fountains and surface filtering.
Visually review regional and street views and at least one non-Latin script after
language/font changes. Test geometry and rendering, not just JSON size.

Published releases are immutable snapshots owned by the website package. After a
style change, bump the version, freeze with `npm run release`, build and test. Keep
all earlier snapshots and routes. Website-only changes do not require a style bump.

## Shared typography

`fonts.js` owns the family registry, default and regular/medium/italic slots. All
text layers and the city-rank expression use those slots; POIs and peaks inherit
them. The Noto names are deliberate logical fallback keys for the existing PBF
service, not a claim that the selected Latin outlines are Noto. `font-faces` puts
the selected family first over its measured Latin/mark/punctuation coverage.
Outside that coverage, Noto native script faces and then Noto PBFs remain active.
Never substitute a font in only one layer or remove script fallbacks.

`latin-fonts.js` contains coverage derived from bundled binaries. Each family
ships copyright and OFL notices and provenance hashes under assets/fonts/latin.
The site imports the same registry for URL validation and its selector. Website
text uses the matching Commissioner variable face; code samples stay monospace.
