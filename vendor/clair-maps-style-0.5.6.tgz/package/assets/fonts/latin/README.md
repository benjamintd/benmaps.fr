# Font licenses and provenance

Reviewed 2026-09-11. Commissioner, Google Sans, Source Sans 3, Inter, Inter Tight
and Pliant use SIL Open Font License 1.1. The separate notices in this directory
contain each copyright statement and complete license. Noto fallbacks retain the
notices listed in THIRD_PARTY.md.

Commercial use, embedding and redistribution with Clair are permitted under OFL.
The fonts remain OFL even when the style is commercially licensed. Retain notices;
do not sell the fonts by themselves or imply endorsement by their authors.
Source Sans reserves the name “Source”: its upstream static TTFs are unmodified.
The other five notices do not declare Reserved Font Names.

SOURCES.json records upstream files and SHA256 hashes. Google Fonts' static TTFs
for Google Sans, Source Sans 3, Inter, Inter Tight and Pliant are unmodified.
Commissioner static faces were instantiated from the upstream variable font at
weight 400/500, slant 0; the italic slot uses weight 400, slant -12. Other axes stay
at their default. This is an oblique instance, not a separately drawn italic.
The website's Commissioner variable WOFF2 is a format conversion of that same
upstream variable TTF, with outlines and copyright/name records retained.

Coverage declarations limit replacement to supported Latin characters, combining
marks and shared punctuation. Non-Latin scripts continue to use Noto even if a
candidate also includes their glyphs. The files retain their complete upstream
coverage; declarations are not font modifications. Update declarations whenever
updating binaries, and verify composed and decomposed diacritics and fallback.

This directory is part of the redistributable package; include it when self-hosting
fonts. https://openfontlicense.org/ explains OFL conditions and permitted use.
