import { kinds, detail } from './tokens.js';

// Protomaps v4 can classify living_street as kind=other. Use its precise
// subtype instead of silently dropping these named streets and bridge approaches.
export const localStreets = ['any', kinds('minor_road'), detail('living_street')];
export const pedestrianStreets = ['all', kinds('path'), detail('pedestrian')];
export const footways = ['all', kinds('path'), detail('footway', 'corridor')];
export const sidewalks = ['all', kinds('path'), detail('sidewalk')];
export const crossings = ['all', kinds('path'), detail('crossing')];
