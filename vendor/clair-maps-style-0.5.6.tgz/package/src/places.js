import { fontStacks } from './fonts.js';
import { zoom } from './tokens.js';

const rank = ['coalesce', ['get', 'min_zoom'], 15];
const population = ['to-number', ['get', 'population'], 0];
export const nationalCapital = ['in', ['to-string', ['get', 'capital']], ['literal', ['yes', '2']]];
export const metropolitanCenter = ['any', nationalCapital, ['>=', population, 1_000_000]];

// At city scales min_zoom alone makes neighbouring communes look equally
// important. National capitals and population give a stable, global hierarchy.
export const cityTextSize = zoom(
  3,
  ['case', ['<=', rank, 4], 14, 11],
  8,
  ['case', ['<=', rank, 7], 16, 11],
  10,
  ['case', nationalCapital, 19, metropolitanCenter, 17, ['>=', population, 100_000], 14, 12],
  13,
  ['case', nationalCapital, 22, metropolitanCenter, 20, ['>=', population, 100_000], 16, 13],
);
export const citySortKey = [
  'case',
  nationalCapital,
  ['-', -1_000_000_000, population],
  ['coalesce', ['get', 'sort_key'], ['-', 0, population]],
];
export const cityFont = [
  'case',
  metropolitanCenter,
  ['literal', fontStacks.medium],
  ['literal', fontStacks.regular],
];
