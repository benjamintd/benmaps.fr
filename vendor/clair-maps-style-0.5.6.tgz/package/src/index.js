import { landLayers, boundaryLayers } from './land.js';
import { roadLayers } from './roads.js';
import { labelLayers } from './labels.js';
import { reliefLayer, elevationSource } from './relief.js';
import {
  buildingLayers,
  buildingLight,
  defaultBuildingHeight as fallbackHeight,
} from './buildings.js';
import { fontFaces, defaultFont } from './fonts.js';
import { treeLayers } from './trees.js';
import { regionalPeakSource } from './peaks.js';
export { defaultBuildingHeight } from './buildings.js';
export { fontChoices, defaultFont } from './fonts.js';
export { palette } from './tokens.js';
export function createStyle({
  apiKey,
  language = 'en',
  font = defaultFont,
  bilingual = false,
  density = 'balanced',
  iconStyle = 'soft',
  assetBase = 'https://protomaps.github.io/basemaps-assets',
  fontBase = '',
  source,
  relief = true,
  terrain = false,
  trees = true,
  regionalPeaks = true,
  groups = {},
  extrusions = false,
  defaultBuildingHeight = fallbackHeight,
} = {}) {
  if (!apiKey && !source) throw new Error('Provide a Protomaps API key or a custom vector source.');
  if (!['soft', 'line'].includes(iconStyle)) throw new Error('iconStyle must be soft or line.');
  const buildings = buildingLayers({ extrusions, defaultHeight: defaultBuildingHeight });
  const land = [...landLayers(), ...buildings.footprints];
  if (relief)
    land.splice(
      land.findIndex((l) => l.id === 'water'),
      0,
      reliefLayer(),
    );
  const layers = [
    ...land,
    ...roadLayers({ surfaceDetails: trees ? treeLayers() : [] }),
    ...boundaryLayers(),
    ...buildings.volumes,
    ...labelLayers({ language, bilingual, density, regionalPeaks }),
  ];
  for (const l of layers) {
    const group = l.id.startsWith('poi-')
      ? 'pois'
      : l.type === 'symbol'
        ? 'labels'
        : l.id.startsWith('building-')
          ? 'buildings'
          : 'base';
    l.metadata = { 'clair:group': group };
    if (groups[group] === false) l.layout = { ...l.layout, visibility: 'none' };
  }
  // Return an independent JSON tree so callers can edit an exported style safely.
  return structuredClone({
    version: 8,
    name: `Clair · ${language}`,
    metadata: {
      'clair:version': '0.5.6',
      'clair:language': language,
      'clair:font': font,
      'clair:bilingual': bilingual,
    },
    ...(terrain ? { terrain: { source: 'terrain', exaggeration: 1 } } : {}),
    ...(extrusions ? { light: buildingLight } : {}),
    glyphs: `${assetBase}/fonts/{fontstack}/{range}.pbf`,
    sprite: [
      { id: 'default', url: `${assetBase}/sprites/v4/light` },
      { id: 'clair', url: `${fontBase}/sprites/${iconStyle === 'soft' ? 'clair-soft' : 'clair'}` },
    ],
    'font-faces': fontFaces(fontBase, language, font),
    sources: {
      ...(regionalPeaks
        ? {
            'regional-peaks': regionalPeakSource(language),
          }
        : {}),
      ...(relief ? { elevation: elevationSource } : {}),
      // Separate DEM instances keep terrain and hillshade rendering independent.
      ...(terrain ? { terrain: { ...elevationSource } } : {}),
      protomaps: source ?? {
        type: 'vector',
        tiles: [
          `https://api.protomaps.com/tiles/v4/{z}/{x}/{y}.mvt?key=${encodeURIComponent(apiKey)}`,
        ],
        maxzoom: 15,
        attribution:
          '<a href="https://protomaps.com">Protomaps</a> © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> · <a href="https://www.naturalearthdata.com">Natural Earth</a>',
      },
    },
    transition: { duration: 250, delay: 0 },
    layers,
  });
}
