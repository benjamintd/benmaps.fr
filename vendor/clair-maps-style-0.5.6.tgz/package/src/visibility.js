/** Surface-only structures. Apply to buildings, water and street furniture,
 * not to roads: a road in a cutting can have a negative stacking layer. */
export const surfaceFeatures = [
  'all',
  ['!=', ['get', 'location'], 'underground'],
  ['!', ['in', ['get', 'underground'], ['literal', [true, 'yes']]]],
  ['!=', ['get', 'is_tunnel'], true],
  ['in', ['coalesce', ['get', 'tunnel'], 'no'], ['literal', [false, 'no']]],
  [
    'any',
    ['>=', ['to-number', ['get', 'layer'], 0], 0],
    ['==', ['get', 'location'], 'overground'],
    ['==', ['get', 'is_bridge'], true],
    ['==', ['get', 'bridge'], 'yes'],
  ],
];

