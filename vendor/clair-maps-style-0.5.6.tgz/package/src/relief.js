import { zoom } from './tokens.js';
export const elevationSource = {
  type: 'raster-dem',
  tiles: ['https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'],
  encoding: 'terrarium',
  tileSize: 256,
  maxzoom: 12,
  attribution:
    'Elevation: <a href="https://github.com/tilezen/joerd/blob/master/docs/attribution.md">Mapzen & data providers</a>',
};
export function reliefLayer() {
  return {
    id: 'terrain-relief',
    type: 'hillshade',
    source: 'elevation',
    minzoom: 3,
    paint: {
      'hillshade-exaggeration': zoom(3, 0.08, 7, 0.18, 10, 0.23, 13, 0.2, 16, 0.16, 19, 0.1),
      'hillshade-shadow-color': '#7e8972',
      'hillshade-highlight-color': '#ffffff',
      'hillshade-accent-color': '#bcc4ab',
      'hillshade-illumination-direction': 315,
      'hillshade-illumination-anchor': 'map',
    },
  };
}
