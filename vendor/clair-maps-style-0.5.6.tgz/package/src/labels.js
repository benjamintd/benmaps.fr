import { poiLayers } from './pois.js';
import { palette as p, zoom, layer, kinds, detail } from './tokens.js';
import { labelText } from './language.js';
import { localStreets } from './road-filters.js';
import { cityTextSize, citySortKey, cityFont } from './places.js';
import { surfaceFeatures } from './visibility.js';
import { peakLayers } from './peaks.js';
import { fontStacks } from './fonts.js';
const { regular, medium, italic } = fontStacks;
const rank = ['coalesce', ['get', 'min_zoom'], 15];
export function labelLayers(options) {
  const text = labelText(options),
    single = labelText({ ...options, bilingual: false });
  const paint = (color, halo = p.halo, w = 1.2) => ({
    'text-color': color,
    'text-halo-color': halo,
    'text-halo-width': w,
    'text-halo-blur': 0.3,
  });
  const base = {
    'text-field': text,
    'text-font': regular,
    'text-size': 12,
    'text-padding': 3,
    'text-max-width': 9,
    'text-line-height': 1.2,
    'symbol-sort-key': rank,
  };
  const out = [
    layer(
      'label-oneway',
      'symbol',
      'roads',
      { 'icon-opacity': 0.6 },
      ['==', ['get', 'oneway'], 'yes'],
      {
        'symbol-placement': 'line',
        'symbol-spacing': 140,
        'icon-image': 'arrow',
        'icon-size': 0.65,
        'icon-rotate': 90,
      },
      { minzoom: 17 },
    ),
    // Secondary detail at the supplied address point. Preserve the identifier
    // verbatim; hyphens, suffixes and local digits are part of the address.
    layer(
      'label-address',
      'symbol',
      'buildings',
      {
        ...paint(p.addressInk, p.halo, 0.8),
        'text-opacity': zoom(16.5, 0, 17.5, 1),
      },
      [
        'all',
        kinds('address'),
        ['==', ['geometry-type'], 'Point'],
        ['!=', ['coalesce', ['get', 'addr_housenumber'], ''], ''],
      ],
      {
        'text-field': ['to-string', ['get', 'addr_housenumber']],
        'text-font': medium,
        'text-size': zoom(16.5, 10, 18, 11, 20, 12),
        'text-padding': 2,
        'text-max-width': 20,
        'text-rotation-alignment': 'viewport',
        'text-pitch-alignment': 'viewport',
      },
      { minzoom: 16.5 },
    ),
    layer(
      'label-water-line',
      'symbol',
      'water',
      paint(p.waterText, p.water, 0.8),
      ['all', ['==', ['geometry-type'], 'LineString'], surfaceFeatures],
      {
        ...base,
        'text-field': single,
        'symbol-placement': 'line',
        'text-font': italic,
        'text-size': 12,
        'symbol-spacing': 500,
      },
      { minzoom: 12 },
    ),
    layer(
      'label-water',
      'symbol',
      'water',
      paint(p.waterText, p.water, 1),
      [
        'all',
        ['==', ['geometry-type'], 'Point'],
        surfaceFeatures,
        ['!=', ['get', 'kind'], 'fountain'],
        ['>=', ['zoom'], ['coalesce', ['get', 'min_zoom'], 0]],
      ],
      { ...base, 'text-font': italic, 'text-size': zoom(3, 11, 8, 13, 14, 15) },
    ),
    layer(
      'label-fountain',
      'symbol',
      'water',
      paint(p.secondary, p.halo, 0.8),
      [
        'all',
        ['==', ['geometry-type'], 'Point'],
        kinds('fountain'),
        surfaceFeatures,
        ['>=', ['zoom'], ['coalesce', ['get', 'min_zoom'], 16]],
      ],
      { ...base, 'text-size': zoom(16, 11, 19, 12), 'text-padding': 5 },
      { minzoom: 16 },
    ),
    layer(
      'label-paths',
      'symbol',
      'roads',
      paint('#737269'),
      ['all', kinds('path'), ['!', detail('sidewalk', 'crossing')]],
      {
        ...base,
        'text-field': single,
        'symbol-placement': 'line',
        'text-size': zoom(15, 10.5, 18, 12, 20, 14),
        'symbol-spacing': 300,
        'text-max-angle': 25,
      },
      { minzoom: 15 },
    ),
    layer(
      'label-streets',
      'symbol',
      'roads',
      paint('#515b5e'),
      localStreets,
      {
        ...base,
        'text-field': single,
        'symbol-placement': 'line',
        'text-size': zoom(13, 10.5, 17, 12, 20, 14),
        'symbol-spacing': 350,
        'text-max-angle': 25,
      },
      { minzoom: 13 },
    ),
    layer(
      'label-arterials',
      'symbol',
      'roads',
      paint('#52616b'),
      kinds('major_road', 'highway'),
      {
        ...base,
        'text-field': single,
        'symbol-placement': 'line',
        'text-size': zoom(11, 10.5, 16, 12.5, 20, 15),
        'symbol-spacing': 420,
        'text-max-angle': 25,
      },
      { minzoom: 11 },
    ),
    layer(
      'label-shields',
      'symbol',
      'roads',
      paint('#526878', p.road, 0.2),
      [
        'all',
        kinds('highway', 'major_road'),
        ['has', 'shield_text'],
        ['<=', ['length', ['get', 'shield_text']], 5],
      ],
      {
        'text-field': ['get', 'shield_text'],
        'text-font': medium,
        'text-size': 10,
        'icon-image': ['concat', 'generic_shield-', ['length', ['get', 'shield_text']], 'char'],
        'icon-size': 1,
        'symbol-placement': 'line',
        'symbol-spacing': 500,
        'text-rotation-alignment': 'viewport',
        'icon-rotation-alignment': 'viewport',
      },
      { minzoom: 8 },
    ),
  ];
  out.push(...poiLayers(options, base, paint));
  out.push(...peakLayers(options, base, paint));
  out.push(
    layer(
      'label-neighbourhood',
      'symbol',
      'places',
      paint(p.secondary, p.land, 1),
      kinds('neighbourhood', 'macrohood'),
      { ...base, 'text-size': zoom(11, 11, 14, 14, 17, 17), 'text-padding': 22 },
      { minzoom: 11, maxzoom: 17 },
    ),
    layer(
      'label-region',
      'symbol',
      'places',
      paint('#7c8383', p.land, 1.4),
      kinds('region'),
      { ...base, 'text-size': zoom(3, 11, 7, 15), 'text-padding': 15 },
      { minzoom: 3, maxzoom: 9 },
    ),
    layer(
      'label-city',
      'symbol',
      'places',
      paint(p.ink, p.land, 1.5),
      kinds('locality'),
      {
        ...base,
        'text-font': cityFont,
        'text-size': cityTextSize,
        'symbol-sort-key': citySortKey,
        'text-padding': zoom(3, 5, 9, 10, 13, 16),
        'icon-image': ['step', ['zoom'], 'townspot', 8, ''],
        'icon-size': 0.6,
        'text-radial-offset': 0.45,
        'text-variable-anchor': [
          'step',
          ['zoom'],
          ['literal', ['left', 'right', 'top', 'bottom']],
          8,
          ['literal', ['center', 'top', 'bottom', 'left', 'right']],
        ],
      },
      { maxzoom: 13 },
    ),
    layer(
      'label-country',
      'symbol',
      'places',
      paint('#52645f', p.land, 1.2),
      kinds('country'),
      {
        ...base,
        'text-field': single,
        'text-font': medium,
        'text-size': zoom(1, 12, 4, 16, 7, 19),
        'text-padding': 12,
      },
      { maxzoom: 8 },
    ),
  );
  return out;
}
