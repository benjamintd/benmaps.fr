import { palette as p, zoom, exp, layer, kinds, detail } from './tokens.js';
import { localStreets, pedestrianStreets, footways, sidewalks, crossings } from './road-filters.js';
import { surfaceFeatures } from './visibility.js';
import { streetWidth } from './street-scale.js';
const roadClasses = [
  {
    id: 'pedestrian',
    filter: pedestrianStreets,
    min: 13,
    width: [13, 0.5, 14, 1.2, 16, 5],
    color: p.paving,
  },
  {
    id: 'footway',
    filter: footways,
    min: 14,
    width: [13, 0, 14, 0.8, 16, 2],
    color: p.paving,
  },
  {
    id: 'steps',
    filter: ['all', kinds('path'), detail('steps')],
    min: 14,
    width: [14, 0.8, 16, 3],
    color: p.paving,
  },
  {
    id: 'service',
    filter: ['all', kinds('minor_road'), detail('service')],
    min: 14,
    width: [12, 0, 14, 0.6, 16, 2],
    color: zoom(16, p.road, 18, p.roadSurface),
  },
  {
    id: 'minor',
    filter: ['all', localStreets, ['!', detail('service')]],
    min: 11,
    width: [10, 0, 12, 0.7, 14, 2, 16, 6.5],
    color: zoom(16, p.road, 18, p.roadSurface),
  },
  {
    id: 'tertiary',
    filter: ['all', kinds('major_road'), detail('tertiary', 'tertiary_link')],
    min: 9,
    width: [8, 0, 10, 0.5, 12, 1.3, 14, 3, 16, 7],
    color: zoom(16, p.road, 18, p.roadSurface),
  },
  {
    id: 'major',
    filter: ['all', kinds('major_road'), ['!', detail('tertiary', 'tertiary_link')]],
    min: 6,
    width: [6, 0.55, 8, 0.85, 10, 1, 12, 1.8, 14, 4, 16, 10],
    color: zoom(7, '#bbc8d1', 12, '#c4cdd4', 15, '#e6eaeb', 18, '#e3e8eb'),
  },
  {
    id: 'highway',
    filter: kinds('highway'),
    min: 4,
    width: [4, 0.45, 6, 0.8, 8, 1.1, 10, 1.7, 12, 2.5, 14, 5, 16, 11],
    color: zoom(4, '#9dabb3', 7, '#a4b2be', 12, p.highway, 16, '#bdc9d2', 20, '#ccd6dd'),
  },
];
function crossingLayers(structure, tier) {
  // Mark only supplied crossing lines. Point features have no orientation.
  return [false, true].map((stripes) =>
    layer(
      `${tier === 'bridge' ? 'bridge-' : ''}crossing-${stripes ? 'stripes' : 'base'}`,
      'line',
      'roads',
      {
        'line-color': stripes ? p.halo : p.crossing,
        'line-width': streetWidth([16, 2]),
        'line-opacity': zoom(16, 0, 17, stripes ? 0.95 : 0.7),
        ...(stripes ? { 'line-dasharray': [0.33, 0.33] } : {}),
      },
      ['all', crossings, surfaceFeatures, structure],
      { 'line-cap': 'butt', 'line-join': 'bevel' },
      { minzoom: 16 },
    ),
  );
}

export function roadLayers({ surfaceDetails = [] } = {}) {
  const out = [
    layer(
      'runways',
      'line',
      'roads',
      { 'line-color': p.runway, 'line-width': exp(10, 1, 14, 7, 18, 45) },
      detail('runway', 'taxiway'),
    ),
    layer(
      'ferries',
      'line',
      'roads',
      {
        'line-color': p.waterText,
        'line-width': 1,
        'line-opacity': 0.55,
        'line-dasharray': [2, 3],
      },
      kinds('ferry'),
      undefined,
      { minzoom: 8 },
    ),
    layer(
      'rail-surface',
      'line',
      'roads',
      { 'line-color': p.rail, 'line-width': zoom(9, 0.4, 14, 1, 18, 2), 'line-opacity': 0.55 },
      ['all', kinds('rail'), ['!=', ['get', 'is_tunnel'], true]],
      undefined,
      { minzoom: 9 },
    ),
    ...[true, false].map((casing) =>
      layer(
        casing ? 'sidewalks-case' : 'sidewalks',
        'line',
        'roads',
        {
          'line-color': casing ? p.pavingEdge : p.paving,
          'line-width': streetWidth([16, 2], { casing: casing ? 1 : 0 }),
          'line-opacity': casing ? zoom(16, 0, 17, 0.6, 19, 0.35) : zoom(16, 0, 17, 1),
        },
        ['all', sidewalks, surfaceFeatures],
        { 'line-cap': 'round', 'line-join': 'round' },
        { minzoom: 16 },
      ),
    ),
    layer(
      'paths',
      'line',
      'roads',
      { 'line-color': p.path, 'line-width': zoom(13, 0.4, 16, 1, 19, 2), 'line-dasharray': [2, 2] },
      [
        'all',
        kinds('path'),
        ['!', detail('steps', 'footway', 'pedestrian', 'sidewalk', 'crossing', 'corridor')],
      ],
      { 'line-cap': 'round' },
      { minzoom: 13 },
    ),
  ];
  // Casings precede all fills within a structure tier, so junctions stay open.
  for (const tier of ['tunnel', 'surface', 'bridge']) {
    const structure =
      tier === 'tunnel'
        ? ['==', ['get', 'is_tunnel'], true]
        : tier === 'bridge'
          ? ['==', ['get', 'is_bridge'], true]
          : ['all', ['!=', ['get', 'is_tunnel'], true], ['!=', ['get', 'is_bridge'], true]];
    for (const casing of [true, false])
      for (const c of roadClasses) {
        const walking = c.id === 'pedestrian' || c.id === 'footway' || c.id === 'steps';
        const paint = {
          'line-color': casing ? (c.id === 'highway' ? p.highwayCase : p.roadCase) : c.color,
          'line-width': streetWidth(c.width, {
            multiplier: ['case', ['==', ['get', 'is_link'], true], 0.65, 1],
            casing: casing ? (tier === 'bridge' ? 1.8 : 1) : 0,
          }),
          // Ground walking lines merge into matching paving. Bridge deck edges
          // remain visible independently of whether an area polygon exists.
          'line-opacity':
            tier === 'tunnel'
              ? 0.45
              : casing && walking && tier === 'surface'
                ? zoom(16, 1, 17.5, 0)
                : casing
                  ? zoom(4, 0, 7, 0.35, 10, 1)
                  : zoom(3.5, 0, 4.5, 1),
        };
        if (tier === 'tunnel' && casing) paint['line-dasharray'] = [3, 2];
        out.push(
          layer(
            `${tier}-${c.id}${casing ? '-case' : ''}`,
            'line',
            'roads',
            paint,
            ['all', structure, c.filter],
            { 'line-cap': walking ? 'butt' : 'round', 'line-join': 'round' },
            { minzoom: c.min },
          ),
        );
      }
    // A staircase is a paved surface with treads, including across water.
    // Keep markings in their structure tier instead of above every bridge.
    out.push(
      layer(
        tier === 'surface' ? 'steps' : `${tier}-steps-marks`,
        'line',
        'roads',
        {
          'line-color': p.path,
          'line-width': streetWidth([16, 3]),
          'line-dasharray': [0.06, 0.12],
          'line-opacity': zoom(16, 0, 17, tier === 'tunnel' ? 0.3 : 0.65),
        },
        ['all', kinds('path'), detail('steps'), structure],
        { 'line-cap': 'butt', 'line-join': 'round' },
        { minzoom: 16 },
      ),
    );
    if (tier !== 'tunnel') out.push(...crossingLayers(structure, tier));
    // Ground canopies may cover a surface street, but never an elevated deck.
    if (tier === 'surface') out.push(...surfaceDetails);
  }
  out.push(
    layer(
      'rail-elevated',
      'line',
      'roads',
      { 'line-color': '#9da6ad', 'line-width': zoom(13, 0.7, 17, 1.3, 20, 2.5) },
      ['all', kinds('rail'), ['==', ['get', 'is_bridge'], true]],
      undefined,
      { minzoom: 13 },
    ),
  );
  return out;
}
