import { palette as p, layer } from './tokens.js';
import { surfaceFeatures } from './visibility.js';

/** Real tree positions, estimated crowns. Ground-aligned circles stay portable
 * in exported JSON and do not compete with labels for symbol placement. */
export function treeLayers() {
  const radius = (scale) => [
    'interpolate',
    ['exponential', 2],
    ['zoom'],
    16,
    3.25 * scale,
    18,
    13 * scale,
    20,
    36 * scale,
  ];
  const filter = [
    'all',
    ['==', ['get', 'kind'], 'tree'],
    surfaceFeatures,
    ['>=', ['zoom'], ['coalesce', ['get', 'min_zoom'], 16]],
  ];
  return [
    ['shadow', p.treeShadow, 1.08, [1.3, 1.8], 0.18],
    ['canopy', p.tree, 1, [0, 0], 1],
    ['light', p.treeLight, 0.85, [-0.7, -0.9], 0.45],
  ].map(([id, color, scale, offset, strength]) =>
    layer(
      `tree-${id}`,
      'circle',
      'pois',
      {
        'circle-radius': radius(scale),
        'circle-color': color,
        'circle-opacity': ['interpolate', ['linear'], ['zoom'], 15.5, 0, 16.5, 0.85 * strength],
        'circle-blur': id === 'shadow' ? 0.6 : id === 'light' ? 1 : 0.15,
        'circle-translate': offset,
        'circle-translate-anchor': 'map',
        'circle-pitch-alignment': 'map',
        'circle-pitch-scale': 'map',
      },
      filter,
      undefined,
      { minzoom: 15.5 },
    ),
  );
}
