import { regionalPeakData } from './peak-data.js';
import { palette as p, zoom, kinds, layer } from './tokens.js';
import { normalizeLanguage, appendLabelLine } from './language.js';

/** Separate regional and detailed sources at z12, so labels never duplicate. */
export function peakLayers(options, base, textPaint) {
  const elevation = ['to-number', ['get', 'elevation'], 0];
  const locale = normalizeLanguage(options.language);
  const field = appendLabelLine(
    base['text-field'],
    [
      'case',
      ['>', elevation, 0],
      [
        'concat',
        '\n',
        [
          'number-format',
          elevation,
          { locale: locale === 'local' ? 'en' : locale, 'max-fraction-digits': 0 },
        ],
        ' m',
      ],
      '',
    ],
    { 'font-scale': 0.82 },
  );
  const rank = ['coalesce', ['get', 'min_zoom'], 12];
  const make = (regional) => {
    const result = layer(
      regional ? 'poi-peaks-regional' : 'poi-peaks',
      'symbol',
      'pois',
      textPaint(p.peakInk),
      ['all', kinds('peak'), ['>=', ['zoom'], ['+', rank, regional ? 1.5 : 0]]],
      {
        ...base,
        'text-field': field,
        'text-size': zoom(7, 11, 12, 12, 16, 13),
        'text-padding': 7,
        'text-max-width': 11,
        'symbol-sort-key': ['-', ['*', rank, 10000], elevation],
        'icon-image': 'clair:nature-peak',
        'icon-size': 0.65,
        'text-variable-anchor': ['top', 'right', 'left', 'bottom'],
        'text-radial-offset': 0.85,
        'text-justify': 'auto',
      },
      { minzoom: regional ? 7 : 12, ...(regional ? { maxzoom: 12 } : {}) },
    );
    if (regional) {
      result.source = 'regional-peaks';
      delete result['source-layer'];
    }
    return result;
  };
  return [...(options.regionalPeaks ? [make(true)] : []), make(false)];
}

/** Export only translations reachable by the fixed language of this style.
 * Preserve source geometry and all non-translation properties; never mutate it. */
export function regionalPeakSource(language) {
  const needed = new Set(['name:en', `name:${normalizeLanguage(language)}`]);
  return {
    type: 'geojson',
    attribution: '<a href="https://www.naturalearthdata.com">Natural Earth</a>',
    data: {
      ...regionalPeakData,
      features: regionalPeakData.features.map((feature) => ({
        ...feature,
        properties: Object.fromEntries(
          Object.entries(feature.properties).filter(
            ([key]) => !key.startsWith('name:') || needed.has(key),
          ),
        ),
      })),
    },
  };
}
