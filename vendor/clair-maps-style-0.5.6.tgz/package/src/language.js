/** MapLibre 6.9+ uses native shaping with font-faces. Never feed pgf:* private
 * codepoints to ordinary fonts. Raw Unicode keeps labels searchable and portable. */
export function normalizeLanguage(tag = 'en') {
  const value = String(tag).replaceAll('_', '-').toLowerCase();
  if (value === 'local') return 'local';
  if (/^zh-(tw|hk|mo|hant)/.test(value)) return 'zh-Hant';
  if (/^zh/.test(value)) return 'zh-Hans';
  return /^[a-z]{2,3}(-[a-z0-9]+)*$/.test(value) ? value.split('-')[0] : 'en';
}
const choose = (keys) => [
  'case',
  ...keys.flatMap((key) => [
    ['all', ['has', key], ['!=', ['get', key], '']],
    ['string', ['get', key]],
  ]),
  '',
];
const local = (slot) => choose([`name${slot}`]);
export function labelText({ language = 'en', bilingual = false, secondaryScale = 0.84 } = {}) {
  const lang = normalizeLanguage(language);
  const localScripts = {
    ar: ['Arabic'],
    he: ['Hebrew'],
    hi: ['Devanagari'],
    th: ['Thai'],
    ja: ['Han', 'Hiragana', 'Katakana', 'Mixed-Japanese'],
    'zh-Hans': ['Han'],
    'zh-Hant': ['Han'],
    ru: ['Cyrillic'],
    uk: ['Cyrillic'],
    el: ['Greek'],
  };
  const scripts = localScripts[lang] || ['Latin'];
  const sameScript = ['in', ['coalesce', ['get', 'script'], 'Latin'], ['literal', scripts]];
  const primary =
    lang === 'local'
      ? choose(['name', 'name:en'])
      : [
          'let',
          'translated',
          choose([`name:${lang}`]),
          'localName',
          local(''),
          [
            'case',
            ['!=', ['var', 'translated'], ''],
            ['var', 'translated'],
            ['all', sameScript, ['!=', ['var', 'localName'], '']],
            ['var', 'localName'],
            choose(['name:en', 'name']),
          ],
        ];
  // Local mode preserves the additional local names in multilingual regions.
  const slots = lang === 'local' ? ['2', '3'] : bilingual ? ['', '2', '3'] : [];
  if (!slots.length) return primary;
  const bindings = ['let', 'primary', primary];
  const parts = ['format', ['var', 'primary'], {}];
  for (const [index, slot] of slots.entries()) {
    const variable = `local${index}`;
    bindings.push(variable, local(slot));
    const name = ['var', variable];
    const earlier = slots.slice(0, index).map((_, i) => ['!=', name, ['var', `local${i}`]]);
    parts.push(
      [
        'case',
        ['all', ['!=', name, ''], ['!=', name, ['var', 'primary']], ...earlier],
        ['concat', '\n', name],
        '',
      ],
      { 'font-scale': secondaryScale },
    );
  }
  return [...bindings, parts];
}

/** Extend formatted labels without losing local-name styling or let scope. */
export function appendLabelLine(text, line, formatting = {}) {
  if (text[0] === 'let')
    return [...text.slice(0, -1), appendLabelLine(text.at(-1), line, formatting)];
  return [...(text[0] === 'format' ? text : ['format', text, {}]), line, formatting];
}
