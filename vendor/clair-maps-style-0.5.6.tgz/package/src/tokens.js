export { palette } from './palette.js';
export const zoom = (...stops) => ['interpolate', ['linear'], ['zoom'], ...stops];
export const exp = (...stops) => ['interpolate', ['exponential', 1.45], ['zoom'], ...stops];
export const kinds = (...values) => ['in', ['get', 'kind'], ['literal', values]];
export const detail = (...values) => ['in', ['get', 'kind_detail'], ['literal', values]];
export const layer = (id, type, sourceLayer, paint, filter, layout, extra = {}) => ({
  id,
  type,
  source: 'protomaps',
  'source-layer': sourceLayer,
  ...(filter ? { filter } : {}),
  ...(layout ? { layout } : {}),
  paint,
  ...extra,
});
