/** Preserve the established overview stops, then double each zoom's width.
 * Above z16 this keeps the estimated ground footprint stable at a given latitude.
 * These are visual estimates, not measured widths or latitude-correct metres. */
export function streetWidth(stops, { multiplier = 1, casing = 0 } = {}) {
  if (stops.at(-2) !== 16) throw new Error('Street widths must end with a z16 anchor.');
  const anchors = [...stops, 22, stops.at(-1) * 64];
  const width = (value) => {
    if (typeof multiplier === 'number') return value * multiplier + casing;
    const scaled = ['*', value, multiplier];
    return casing === 0 ? scaled : ['+', scaled, casing];
  };
  return [
    'interpolate',
    ['exponential', 2],
    ['zoom'],
    ...anchors.map((value, index) => (index % 2 ? width(value) : value)),
  ];
}
