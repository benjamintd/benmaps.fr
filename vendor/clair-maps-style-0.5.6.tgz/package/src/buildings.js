import { palette as p, zoom, layer, kinds } from './tokens.js';
import { surfaceFeatures } from './visibility.js';

const visibleBuildings = ['all', kinds('building', 'building_part'), surfaceFeatures];

export const defaultBuildingHeight = 9;
export const buildingLight = {
  anchor: 'viewport',
  position: [1.5, 315, 45],
  color: '#fffdf8',
  intensity: 0.18,
};

export function buildingLayers({ extrusions = false, defaultHeight = defaultBuildingHeight } = {}) {
  if (!Number.isFinite(defaultHeight) || defaultHeight < 0)
    throw new RangeError('defaultBuildingHeight must be a finite, non-negative number of metres.');
  const footprints = [
    layer(
      'building-shadow',
      'fill',
      'buildings',
      {
        'fill-color': '#b9b1a4',
        'fill-opacity': zoom(15, 0, 17, 0.13, 19, 0.22),
        'fill-translate': [1.1, 1.6],
      },
      visibleBuildings,
      undefined,
      { minzoom: 15 },
    ),
    layer(
      'building-fill',
      'fill',
      'buildings',
      { 'fill-color': p.building, 'fill-opacity': zoom(13, 0, 14, 0.28, 15, 0.65, 17, 1) },
      visibleBuildings,
      undefined,
      { minzoom: 13 },
    ),
    layer(
      'building-outline',
      'line',
      'buildings',
      {
        'line-color': p.buildingEdge,
        'line-width': zoom(15, 0, 17, 0.6, 19, 0.9),
        'line-opacity': zoom(15, 0, 16, 0.7),
      },
      visibleBuildings,
      undefined,
      { minzoom: 15 },
    ),
  ];
  if (!extrusions) return { footprints, volumes: [] };

  // z0–14 geometry is merged. Switch to individual buildings at z15,
  // growing the base and roof together to full height by z16.
  for (const footprint of footprints) footprint.maxzoom = 15;
  const rawBase = ['max', 0, ['number', ['get', 'min_height'], 0]];
  const height = ['max', 0, ['number', ['get', 'height'], ['+', rawBase, defaultHeight]]];
  const base = ['min', rawBase, height];
  const volumes = [
    layer(
      'building-extrusion',
      'fill-extrusion',
      'buildings',
      {
        'fill-extrusion-color': p.building,
        'fill-extrusion-height': zoom(15, 0, 16, height),
        'fill-extrusion-base': zoom(15, 0, 16, base),
        'fill-extrusion-opacity': 1,
        'fill-extrusion-vertical-gradient': true,
      },
      ['all', visibleBuildings, ['==', ['geometry-type'], 'Polygon']],
      undefined,
      { minzoom: 15 },
    ),
  ];
  return { footprints, volumes };
}
