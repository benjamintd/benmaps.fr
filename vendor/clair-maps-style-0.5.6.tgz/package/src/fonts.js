import { latinFonts } from './latin-fonts.js';
import { cjkFonts } from './cjk-fonts.js';
import { normalizeLanguage } from './language.js';
// Logical slots retain Noto names so missing glyphs can use the existing PBF service.
// Selected Latin faces override these slots by actual coverage; other scripts retain Noto.
export const fontStacks = Object.freeze({
  regular: Object.freeze(['Noto Sans Regular']),
  medium: Object.freeze(['Noto Sans Medium']),
  italic: Object.freeze(['Noto Sans Italic']),
});
export const fontChoices = Object.freeze({
  commissioner: 'Commissioner',
  'google-sans': 'Google Sans',
  'source-sans': 'Source Sans 3',
  inter: 'Inter',
  'inter-tight': 'Inter Tight',
  pliant: 'Pliant',
  noto: 'Noto Sans',
});
export const defaultFont = 'commissioner';
export function fontFaces(assetBase, language = 'en', font = defaultFont) {
  if (!Object.hasOwn(fontChoices, font)) throw new Error('Unsupported font: ' + font);
  const selected = latinFonts[font];
  const scripts = [
    ['Arabic', ['U+0600-06FF', 'U+0750-077F', 'U+08A0-08FF', 'U+FB50-FDFF', 'U+FE70-FEFF']],
    ['Hebrew', ['U+0590-05FF', 'U+FB1D-FB4F']],
    ['Devanagari', ['U+0900-097F', 'U+A8E0-A8FF']],
    ['Thai', ['U+0E00-0E7F']],
  ];
  const cjk =
    normalizeLanguage(language) === 'zh-Hant'
      ? 'TC'
      : normalizeLanguage(language) === 'zh-Hans'
        ? 'SC'
        : 'JP';
  const faces = scripts
    .map(([script, range]) => ({
      url: `${assetBase}/fonts/NotoSans${script}-Regular.ttf`,
      'unicode-range': range,
    }))
    .concat(
      cjkFonts[cjk].map((face) => ({
        ...face,
        'unicode-range': face['unicode-range'].map((range) =>
          range.replace(/^(U\+[0-9a-f]+)-([0-9a-f]+)$/i, (value, start, end) =>
            start.slice(2).toLowerCase() === end.toLowerCase() ? start : value,
          ),
        ),
      })),
    );
  return Object.fromEntries(
    Object.entries(fontStacks).map(([role, [slot]]) => {
      const face = selected?.faces[role[0].toUpperCase() + role.slice(1)];
      return [
        slot,
        face
          ? [
              { url: `${assetBase}/fonts/latin/${face.file}`, 'unicode-range': face.ranges },
              ...faces,
            ]
          : [...faces],
      ];
    }),
  );
}
