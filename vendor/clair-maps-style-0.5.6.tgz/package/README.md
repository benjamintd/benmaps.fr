# Clair style

A standalone, programmatically generated light MapLibre style for the Protomaps v4 vector-tile schema. Zero runtime dependencies. The package includes the style modules, local Noto script fonts, original line POI SVGs, generated soft-relief POI icons, and prebuilt 1×/2× sprite atlases. It includes no viewer, build tools, map-renderer runtime or personal API key.

## Use

```js
import { createStyle } from '@clair-maps/style';

const style = createStyle({
  apiKey: 'YOUR_PROTOMAPS_KEY',
  language: 'en',
  bilingual: false,
  density: 'balanced',
  relief: true,
  trees: true,
  regionalPeaks: true,
  extrusions: false, // opt in to 3D buildings
  defaultBuildingHeight: 9, // metres, when source height is missing
  iconStyle: 'soft', // or 'line'
  fontBase: 'https://your-app.example/clair',
});
// Pass style to your MapLibre Map constructor.
```

Copy this package's `assets/` contents into your app's public `clair/` directory. `fontBase` points to that directory; both `fonts/` and `sprites/` must be served from it. Use MapLibre GL JS 6.9+ for the font-face and native complex-script shaping features. The package only returns style JSON and does not initialize a map.

`language` accepts a language tag or `local`; `bilingual` adds distinct local names. `density` is `balanced` or `quiet`. `groups` accepts `pois`, `labels`, and `buildings` visibility flags. Use `relief:false` to remove the terrain source and layer. A custom vector `source` can replace the Protomaps API source and removes the requirement for `apiKey`; it must expose the same layer/property schema.

The `assetBase` option controls the baseline Protomaps glyph/sprite host. Noto CJK subsets are currently pinned remote WOFF2 URLs in `src/cjk-fonts.js`. Fully self-hosted applications should mirror those font subsets and the baseline glyph/sprite assets, and replace the optional elevation source. The supplied four local script fonts cover Arabic, Hebrew, Devanagari and Thai.

## Buildings and icons

`extrusions:true` enables shaded building volumes at z15, growing to full source height by z16. Lower zooms keep the flat footprints because Protomaps merges building geometry below z15. The default is flat cartography. Set the consuming map's `pitch` (for example 50°) to view the volumes; the factory does not control the camera.

Recorded `height` and `min_height` are used in metres. Missing/non-numeric heights use `defaultBuildingHeight` (9 m by default); a raised part without a roof height gets that much thickness above its base. Explicit zero stays zero, negative heights clamp to ground, and a base above a known roof clamps to the roof. The fallback must be finite and non-negative; 0 keeps unknown, ground-level buildings flat. This is a cartographic approximation, not inferred actual height. Source height may itself be derived from OSM building levels. Polygon overlaps and roofs are limited by the source geometry; no facade textures, roof modeling or landmark meshes are supplied.

`iconStyle:'soft'` selects the default generated badges; `'line'` retains the original SVG-derived symbols. Both atlases use the same 30 IDs and category mapping. Each sprite cell is 24px at 1× and 48px at 2×; the map renders them at an icon size of 0.85. Ship both atlas pairs if users can switch styles.

## Terrain and street detail

Hillshade remains subtle but visible through street zooms. Bare rock, scree, grassland and glacier polygons have distinct semantic fills. The elevation source tops out at z12 and is overzoomed for close views; this shows broad slopes, not survey-grade microterrain or a 3D terrain mesh.

`regionalPeaks:true` includes 633 public-domain Natural Earth mountain points, embedded in the returned style (no extra service or credential). They label regional scales from z7 to z12, then give way to Protomaps peak features. Names use the same language fallback as other labels, with localized metric elevations. Natural Earth's default name is not guaranteed to be the local endonym; `local` falls back to that supplied name. Elevations are source values, not current snow-height measurements. Use `regionalPeaks:false` to omit this supplementary source; detailed Protomaps peaks remain.

`trees:true` renders real source tree points as shaded, ground-aligned canopies at z16+. Crowns use an estimated size with a close-zoom cap; they are not measured canopy outlines or 3D tree models. Trees remain visible when POI labels are disabled. `trees:false` removes their three lightweight circle layers.

Crossing markings follow only `roads` linework classified as `path/crossing`. Point crossings are not assigned guessed orientations. Their stripe width is a cartographic default, not an assertion about local traffic-sign standards. Tree and crossing coverage depends on the source data.

Surface structures share one visibility rule: explicit underground/tunnel metadata hides them; negative `layer` is a fallback except for explicitly overground or bridge features. The rule applies to building footprints/shadows/extrusions, water and its labels, mapped facilities, trees and crossings. It deliberately does not hide all negative-layer roads, since layer describes relative stacking and roads can be in open cuttings. Station POIs remain independent of building visibility. If a tile has dropped underground metadata, the style cannot recover it.

## Package boundaries

- `src/`: palette, land, buildings, roads, places, labels, language, POIs and style assembly.
- `assets/fonts/`: local OpenType fonts and OFL license.
- `assets/sprites/`: ready-to-serve atlases and original SVGs.

Changes to geometry, language and palette remain independent. City hierarchy is based on capital status/population; road rules use semantic types, never location-name exceptions.

Clair 0.5.0 and later are free for noncommercial use under the Clair License 1.0. Commercial use up to 10,000 daily map users requires a one-time US$199 license; larger audiences require a separate agreement. Fonts, source map data and upstream assets retain their own licenses; see THIRD_PARTY.md. Basemap, terrain and provider attribution must remain visible in the consuming map.

### Close-scale streets and surfaces

From z16 to z22, estimated road, sidewalk, crossing and stair widths double each zoom, keeping a stable ground footprint at a given latitude. Earlier overview anchor values are preserved. This is not a measured-width model: Protomaps v4 omits lane counts and width tags, and these pixel anchors are not latitude-correct metre values.

Mapped pedestrian/sidewalk/platform polygons define paving outlines. Walking line fills share their color, with ground casings fading out by z17.5 to avoid outlining a second street inside a square. Vehicle surfaces acquire a restrained gray-blue tint at close zooms, distinct from warm paving. Bridge edges remain visible; stepped bridges receive solid decks beneath their treads. Walking paths use flat ends to avoid rounded protrusions into canals.

The source collapses several OSM area types into `kind=pedestrian`; it does not provide a complete curb network or a reliable polygon-to-road relationship. Fallback strokes are not spatially clipped to polygons, and some road/sidewalk overlaps remain approximate. No additional tile source, renderer hook or location-specific data is required.

### Address numbers

Address points in the Protomaps `buildings` layer appear gradually around z17, with small unbadged numbers below street/POI label priority. Their source strings and positions are preserved, including hyphens, suffixes and non-Latin digits. They belong to the Labels group and remain available with buildings or POIs hidden. Coverage depends on the delivered points; tile-wide upstream address deduplication can discard distinct addresses, which the style cannot recover.

## Maintaining the generator

See [ARCHITECTURE.md](ARCHITECTURE.md) for module responsibilities, layer ordering,
source limitations, data provenance and output compaction rules. Language-specific
exports retain only reachable peak translations; regenerate the style to switch language.

### Typography

`font` selects the Latin typeface for every label. Default: `commissioner`. Options:
`google-sans`, `source-sans`, `inter`, `inter-tight`, `pliant`, `noto`. Exported
`fontChoices` and `defaultFont` let consumers build a selector from the same registry.
Pass `fontBase` pointing to the package assets directory. Only the selected family's
regular, medium and italic faces are referenced. Noto handles uncovered codepoints
and non-Latin scripts. Requires MapLibre GL JS 6.9+ native `font-faces` support.

All fonts retain SIL OFL 1.1 terms, separately from the Clair license. See
`assets/fonts/latin/README.md` for the license audit and source provenance.

### 3D terrain

`terrain: true` enables natural-scale 3D terrain using the existing Mapzen
Terrarium elevation tiles. Default is false. It is independent of `relief`
(hillshading) and `extrusions` (buildings). Terrain and hillshading use separate
DEM source entries, preserving the same provider attribution. The current DEM
source stops at zoom 12; higher map zooms interpolate that available detail.
